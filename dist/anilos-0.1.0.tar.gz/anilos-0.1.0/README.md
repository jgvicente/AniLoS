# AniLoS

**AniLoS** (Anisotropic Line-of-Sight) is a Python package that computes the spherical harmonic coefficients (`a_lm`s) of the Cosmic Microwave Background (CMB) temperature and polarization perturbations.

---

## Installation

Install AniLoS directly from the GitHub repository:

```bash
    pip install git+https://github.com/jgvicente/AniLoS
```

---

## Requirements

AniLoS requires **Python 3.10+** and the following Python packages:

* `numpy >= 2.0.2`
* `scipy >= 1.13.0`
* `numba >= 0.61.0`

AniLoS also depends on the [CLASS](http://class-code.net/) and the `classy` Python wrapper to compute background cosmological quantities. These are **not installed automatically** with `pip`, so you must install them manually.

AniLoS is compatible with both `CLASS` and [AniCLASS](https://github.com/pitrou/AniCLASS).

---

## Examples

Example notebooks are available in the [`examples/`](./examples) folder. To run them, you’ll also need:

* `matplotlib`
* `healpy`

To run the notebook `figures_paper.ipynb`, you also need `AniCLASS`.

---

## Modifying radial functions

To modify the radial functions defined in the Cython source:

1. Edit `hybess.pyx` as needed. Once you have finished, follow the instructions in `setup.py`.

2. Rebuild the Cython extension:

   ```bash
   python setup.py build_ext --inplace
   ```

   This will update `hybess.c` with your changes.

3. Build the updated package:

   ```bash
   python -m build
   ```

4. Install the updated version using `pip`:

   ```bash
   cd dist
   pip install <package>
   ```

   Replace `<package>` with the actual filename of the `.whl` or `.tar.gz` file (including the file extension).

---

## Citation

TBA.

## License

AniLoS is released under the GNU General Public License v3.0.
